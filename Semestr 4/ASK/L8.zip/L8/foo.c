// extern int bar;

long foo = 19;
// int *bar_p = &bar;
char code[17];
