// extern long foo;

int bar = 42;
// long *foo_p = &foo;
short dead[15];
