package zadanie2;

import org.junit.jupiter.api.*;
import org.mockito.*;
import zadanie2.*;
import java.util.*;
import java.io.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class GenericTest{

    GenericDAO genericDao =  new GenericDAO();
    private Session session = Mockito.mock(Session.class);
    private DbLogger dbLogger = Mockito.mock(DbLogger.class);
    Object object = new Object();
    @Test
    public void testSave1() throws SessionOpenException{
        genericDao.setSession(session);
        Mockito.doThrow(SessionOpenException.class).when(session).open();
        Assertions.assertThrows(SessionOpenException.class, () -> genericDao.save(object));

        

        // CarService carService = new CarService();
        // carService.setEntityManager(carDao);
        // Car carTest1 = new Car();
        // carTest1.setId(1l);
        // HashMap<String, Long> hashMap1 = new HashMap<>();
        // hashMap1.put("2000", 10l);
        // hashMap1.put("2003", 15l);
        // hashMap1.put("2013", 9975l);
        // carTest1.setYearMileage(hashMap1);
        // Mockito.when(carDao.findById(1l)).thenReturn(carTest1);
        // Assertions.assertEquals(10000l, carService.findMileageBetweenYears(1l,"2000", "2020"));
    }
    @Captor
    private ArgumentCaptor<Exception> exceptionCaptor;

    @Test
    public void testSave2() throws SessionOpenException, CommitException{
        genericDao.setDbLogger(dbLogger);
        genericDao.setSession(session);
        Mockito.doThrow(CommitException.class).when(session).commitTransaction();
        genericDao.save(object);
        Mockito.verify(dbLogger).log(exceptionCaptor.capture());
        Assertions.assertTrue(exceptionCaptor.getAllValues().stream().findFirst().get() instanceof CommitException);
    }
}