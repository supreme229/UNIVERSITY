package zadanie1;

import org.junit.jupiter.api.*;
import org.mockito.*;
import zadanie1.*;
import java.util.*;

public class CarTest{

    private CarDAO carDao = Mockito.mock(CarDAO.class);
    @Test
    public void testFindMileageBetweenYears(){
        CarService carService = new CarService();
        carService.setEntityManager(carDao);
        Car carTest1 = new Car();
        carTest1.setId(1l);
        HashMap<String, Long> hashMap1 = new HashMap<>();
        hashMap1.put("2000", 10l);
        hashMap1.put("2003", 15l);
        hashMap1.put("2013", 9975l);
        carTest1.setYearMileage(hashMap1);
        Mockito.when(carDao.findById(1l)).thenReturn(carTest1);
        Assertions.assertEquals(10000l, carService.findMileageBetweenYears(1l,"2000", "2020"));
    }
}