package zadanie2;

public class CommitException extends Exception {
}
