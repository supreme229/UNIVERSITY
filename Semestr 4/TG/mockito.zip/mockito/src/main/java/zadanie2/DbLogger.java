package zadanie2;

public class DbLogger {

    public void log(Exception e) {

    }

}
