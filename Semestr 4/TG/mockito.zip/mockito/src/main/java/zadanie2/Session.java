package zadanie2;

public class Session {

    public void save(Object o) {

    }

    public void open() throws SessionOpenException{

    }

    public void openTransaction() {


    }

    public void commitTransaction() throws CommitException {

    }

    public void rollbackTransaction() {

    }

    public void close() {

    }



}
