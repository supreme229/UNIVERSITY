package zadanie2;

public class SessionOpenException extends Exception {
}
