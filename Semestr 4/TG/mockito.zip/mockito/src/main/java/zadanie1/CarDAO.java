package zadanie1;

public class CarDAO {

    public Car findById(Long id) {
        return null;
    }
}
